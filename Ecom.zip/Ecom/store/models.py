from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class User(models.Model):
    username=models.CharField(max_length=20,null=True)
    password=models.TextField(null=True)
    email=models.EmailField(null=True)
    
    def __srt__(self):
        return self.username


class Product(models.Model):
    name=models.CharField(max_length=20)
    des=models.TextField(blank=True)
    price=models.DecimalField(max_digits=100,decimal_places=2)
    stock=models.IntegerField()

    def __str__(self):
        return self.name


class Order(models.Model):
    user_id=models.ForeignKey(User,on_delete=models.CASCADE,null=True,related_name='user')
    pdt_id=models.ForeignKey(Product,on_delete=models.CASCADE,null=True,related_name='product')
    quantity=models.IntegerField
    price=models.DecimalField
    order_date=models.DateTimeField(null=True)

    def __str__(self):
        return f'{self.pdt_id}-{self.user_id}'


 
# class Order_item(models.Model):
#     order=models.ForeignKey(Order,on_delete=models.CASCADE,name='itms')
#     product=models.ForeignKey(Product,on_delete=models.CASCADE)
#     quantity=models.IntegerField()


#     def __str__(self):
#         return self.product.name